package com.example.chuyende2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.chuyende2.databinding.FragmentRegisterBinding
import com.example.chuyende2.model.User
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class RegisterFragment : Fragment() {
    private lateinit var dbRef: DatabaseReference
    private lateinit var binding: FragmentRegisterBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        dbRef = FirebaseDatabase.getInstance().getReference("Users")
        binding = FragmentRegisterBinding.inflate(inflater)
        binding.registerButton.setOnClickListener{
            registerUser()
        }
        val activity = requireActivity()
        activity.title = "Register"
        (activity as MainActivity).hideBottomNavigation()
        return binding.root
    }

    private fun registerUser() {
        val userName = binding.userName.editText?.text.toString()
        val passWord = binding.password.editText?.text.toString()
        val passWAgain = binding.passwordAgain.editText?.toString()
        if(passWord != passWAgain){
            Toast.makeText(this.context,"Wrong password, check again!", Toast.LENGTH_SHORT).show()
            return
        }
        val userID = dbRef.push().key!!
        val user = User(userID, userName!!, passWord!!)
        dbRef.child(userID).setValue(user).addOnCompleteListener {
            Toast.makeText(this.context,"Register completed", Toast.LENGTH_SHORT).show()
        }
            .addOnFailureListener{
                Toast.makeText(this.context,"Register failed", Toast.LENGTH_SHORT).show()
            }
     //   Toast.makeText(this.context,"data insert ", Toast.LENGTH_SHORT).show()
    }

}