package com.example.chuyende2.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.chuyende2.R
import com.example.chuyende2.viewmodels.ProductViewModel

class CardAdapter(private val viewModel: ProductViewModel,val lambda:(Double) -> Unit) :RecyclerView.Adapter<CardAdapter.CartViewHoder>(){

    class CartViewHoder(val view: View) : RecyclerView.ViewHolder(view) {
        val image = view.findViewById<ImageView>(R.id.item_card)
        val txname= view.findViewById<TextView>(R.id.card_name)
        val tx1 = view.findViewById<TextView>(R.id.item_card_price)
        val tx2 = view.findViewById<TextView>(R.id.item_card_quantity)
        val increase = view.findViewById<ImageView>(R.id.increase_item)
        val decrease = view.findViewById<ImageView>(R.id.decrease_item)
        val check = view.findViewById<CheckBox>(R.id.check)
        val itemcardtotal = view.findViewById<TextView>(R.id.item_card_total)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHoder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHoder(layout)
    }

    override fun getItemCount(): Int {
        return viewModel.categoris.value?.size ?: -1
    }

    override fun onBindViewHolder(holder: CartViewHoder, position: Int) {
        holder.itemcardtotal.text = viewModel.categoris.value?.get(position)?.price ?: ""
        holder.txname.text = viewModel.categoris.value?.get(position)?.name ?: ""
        holder.tx1.text = viewModel.categoris.value?.get(position)?.price ?: ""
        holder.tx2.text = viewModel.categoris.value?.get(position)?.quantity ?: ""
        viewModel.categoris.value?.get(position)?.thumbnail?.let {
            val imgUri = it.toUri().buildUpon().scheme("https").build()
            holder.image.load(imgUri) {
                placeholder(R.drawable.loading_animation)
                error(R.drawable.ic_broken_image)
            }
        }
//        holder.view.setOnClickListener {
////            lambda(viewModel.categoris.value?.get(position)?.id.toString())
//        }
        holder.increase.setOnClickListener{
            if (viewModel.categoris.value?.get(position)?.quantity!!.toInt() < viewModel.products.value?.get(position)?.quantity!!.toInt())
            {
                viewModel._categoris.value?.get(position)?.quantity = (viewModel.categoris.value?.get(position)?.quantity!!.toInt()+1).toString()
                holder.tx2.text =  viewModel.categoris.value?.get(position)?.quantity ?: ""
                holder.itemcardtotal.text = (viewModel.categoris.value?.get(position)?.quantity!!.toInt()*holder.tx1.text.toString().toDouble()).toString()
                if(holder.check.isChecked){
                    viewModel.plusTotal(viewModel.categoris.value?.get(position)?.price.toString().toDouble())
                    lambda(viewModel.total.value!!)
                    viewModel.addOrderProduct(viewModel.categoris.value?.get(position)!!)
                }
            }
        }
        holder.decrease.setOnClickListener{
            if ((viewModel.categoris.value?.get(position)?.quantity!!.toInt()-1) >0)
            {
                viewModel._categoris.value?.get(position)?.quantity = (viewModel.categoris.value?.get(position)?.quantity!!.toInt()-1).toString()
                holder.tx2.text =  viewModel.categoris.value?.get(position)?.quantity ?: ""
                holder.itemcardtotal.text = (viewModel.categoris.value?.get(position)?.quantity!!.toInt()*holder.tx1.text.toString().toDouble()).toString()
                if(holder.check.isChecked){
                    viewModel.plusTotal(viewModel.categoris.value?.get(position)?.price.toString().toDouble()*(-1))
                    lambda(viewModel.total.value!!)
                    viewModel.addOrderProduct(viewModel.categoris.value?.get(position)!!)
                }
            }
            else{
         //       viewModel.categoris.value!!.drop(position)
                viewModel.subCardProduct(viewModel.categoris.value?.get(position)!!)
            }
        }
        holder.check.setOnClickListener{
            if(holder.check.isChecked){
                viewModel.plusTotal((viewModel.categoris.value?.get(position)?.quantity!!.toInt()*viewModel.categoris.value?.get(position)?.price!!.toDouble()))
                lambda(viewModel.total.value!!)
           //     viewModel.addCardProduct(viewModel.categoris.value?.get(position)!!)
                viewModel.addOrderProduct(viewModel.categoris.value?.get(position)!!)
            }
            else{
                viewModel.subOrderProduct(viewModel.categoris.value?.get(position)!!)
                viewModel.plusTotal((viewModel.categoris.value?.get(position)?.quantity!!.toInt()*viewModel.categoris.value?.get(position)?.price!!.toDouble())*(-1))
                lambda(viewModel.total.value!!)
                viewModel.subCardProduct(viewModel.categoris.value?.get(position)!!)
            }
        }

    }
}

