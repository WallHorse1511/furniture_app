package com.example.recipe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recipe.adapter.RestaurantListAdapter
import com.example.recipe.models.RestaurantModel
import com.google.gson.Gson
import java.io.*
import java.nio.Buffer

class MainActivity : AppCompatActivity(), RestaurantListAdapter.RestaurantListClicker {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val actionBar : ActionBar? = supportActionBar
        actionBar?.setTitle("SeaFood List")
        val restaurantModel = getRestaurentData()
        initRecycleView(restaurantModel)
    }
    private fun initRecycleView(restaurantModel: List<RestaurantModel?>?){
        val recyclerViewRestauran = findViewById<RecyclerView>(R.id.recyclerViewRestaurant)
        recyclerViewRestauran.layoutManager =  LinearLayoutManager(this)
        val adapter = RestaurantListAdapter(restaurantModel,this)
        recyclerViewRestauran.adapter =adapter
    }
    private fun getRestaurentData(): List<RestaurantModel?>?{
        val inputStream: InputStream= resources.openRawResource(R.raw.restaurant)
        val writer: Writer = StringWriter()
        val buffer = CharArray(1024)
        try {
            val reader: Reader= BufferedReader(InputStreamReader(inputStream,"UTF-8"))
            var n: Int
            while(reader.read(buffer).also { n=it }!=-1){
                writer.write(buffer,0,n)
            }
        }catch (e : Exception) {}
            val jsonStr: String = writer.toString()
            val gson = Gson()
            val restaurantModel = gson.fromJson<Array<RestaurantModel>>(jsonStr,
                Array<RestaurantModel>::class.java).toList()
            return  restaurantModel

    }

    override fun onItemClick(restaurantModel: RestaurantModel) {
        val intent= Intent(this@MainActivity, RestaurantMenuActivity::class.java)
        intent.putExtra("RestaurantModel",restaurantModel)
        startActivity(intent)
    }
}
