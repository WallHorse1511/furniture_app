package com.example.chuyende2

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.chuyende2.databinding.FragmentLoginBinding
import com.example.chuyende2.model.User
import com.example.chuyende2.viewmodels.ProductViewModel
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.database.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [LoginFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class LoginFragment : Fragment() {
    private lateinit var usernameEditText: TextInputLayout
    private lateinit var passwordEditText: TextInputLayout
    private lateinit var loginButton: Button
    private val viewModel: ProductViewModel by activityViewModels()
    private lateinit var binding: FragmentLoginBinding
    private lateinit var dbRef : DatabaseReference
    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
    //    val view = inflater.inflate(R.layout.fragment_login, container, false)
        //   Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater)
        val activity = requireActivity()
        activity.title = "Loggin"
        usernameEditText = binding.userName
        passwordEditText = binding.password
        loginButton = binding.loginButton
        (activity as MainActivity).hideBottomNavigation()
        loginButton.setOnClickListener { onLoginButtonClick() }
        binding.registerButton.setOnClickListener{onRegisterButtonClick()}
        return binding.root
    }

    private fun onRegisterButtonClick() {
        findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    private fun onLoginButtonClick() {

        val username = usernameEditText.editText?.text.toString()
        val password = passwordEditText.editText?.text.toString()
        dbRef = FirebaseDatabase.getInstance().getReference("Users")
        dbRef.addValueEventListener(object :ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    for (userSnap in snapshot.children){
                        var userData = userSnap.getValue(User::class.java)
                        if(userData?.userName ?: false ==username && userData?.userPW ?: false == password){
                            viewModel.id = userData?.id!!
                            viewModel.name = username
                            findNavController().navigate(R.id.action_loginFragment_to_productGridFragment)
                            Toast.makeText(activity, "Login completed $username", Toast.LENGTH_SHORT).show()
                            return
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })

    }
}

