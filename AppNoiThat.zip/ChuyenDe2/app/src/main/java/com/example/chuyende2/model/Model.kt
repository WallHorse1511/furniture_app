package com.example.chuyende2.model

class User(val id: String? = null
           , val userName:String? = null,
           val userPW: String? = null)


class Products(val description: String? = null,
    var id: String? = null,
    val id_type: String? = null, val material : String? = null,
    val name: String? = null, val price: String? = null,
    var quantity: String? = null, val sizes: String? = null,
    val thumbnail: String? = null)

class Category(val id: String,val category_name: String)

class Order(
    val orderId: String? = null,
    val customerId: String? = null,
    val name: String? = null,
    val phone: String? = null,
    val city: String? = null,
    val street: String? = null,
    val houseNumber: String? = null,
    val productList: List<Products>? = null,
    var status: Int = 0
)

