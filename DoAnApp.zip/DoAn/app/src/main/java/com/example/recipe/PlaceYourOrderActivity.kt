package com.example.recipe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.ActionBar
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recipe.adapter.PlaceYourOrderAdapter
import com.example.recipe.models.RestaurantModel
import kotlinx.android.synthetic.main.activity_place_your_order.*

class PlaceYourOrderActivity : AppCompatActivity() {
    var placeYourOrderAdapter: PlaceYourOrderAdapter?=null
    var isDeliveryOn: Boolean= false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_place_your_order)
        val restaurantModel: RestaurantModel?=intent.getParcelableExtra("RestaurantModel")
        val actionBar: ActionBar?= supportActionBar
        actionBar?.setTitle(restaurantModel?.name)
        actionBar?.setSubtitle(restaurantModel?.address)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        buttonPlaceYourOrder.setOnClickListener {
            onPlaceOrderButtonClick(restaurantModel)
        }
        switchDelivery?.setOnCheckedChangeListener {  buttonView, isChecked ->
            if(isChecked){
                inputAddress.visibility= View.VISIBLE
                inputCity.visibility=View.VISIBLE
                inputState.visibility=View.VISIBLE
                inputZip.visibility=View.VISIBLE
                tvDeliveryCharge.visibility=View.VISIBLE
                tvDeliveryChargeAmount.visibility=View.VISIBLE
                isDeliveryOn=true
                calculateToTalAmout(restaurantModel)
            }
            else{
                inputAddress.visibility= View.GONE
                inputCity.visibility=View.GONE
                inputState.visibility=View.GONE
                inputZip.visibility=View.GONE
                tvDeliveryCharge.visibility=View.GONE
                tvDeliveryChargeAmount.visibility=View.GONE
                isDeliveryOn = false
                calculateToTalAmout(restaurantModel)
            }
        }
        initRecycleView(restaurantModel)
        calculateToTalAmout(restaurantModel)
    }
    private fun initRecycleView(restaurantModel:RestaurantModel?){
        cartItemsRecyclerView.layoutManager= LinearLayoutManager(this)
        placeYourOrderAdapter=PlaceYourOrderAdapter(restaurantModel?.menus)
        cartItemsRecyclerView.adapter=placeYourOrderAdapter
    }
    private fun calculateToTalAmout(restaurantModel:RestaurantModel?){
        var subTotalAmout= 0f
        for(menu in restaurantModel?.menus!!)
            subTotalAmout+=menu?.price!!*menu?.totalInCart!!
        tvSubtotalAmount.text="$"+String.format("%.2f",subTotalAmout)
        if(isDeliveryOn){
            tvDeliveryChargeAmount.text = "$"+String.format("%.2f",restaurantModel.delivery_charge?.toFloat())
            subTotalAmout+=restaurantModel?.delivery_charge?.toFloat()!!
        }
        tvTotalAmount.text= "$"+String.format("%.2f",subTotalAmout)
    }
    private  fun onPlaceOrderButtonClick(restaurantModel: RestaurantModel?){
        if(TextUtils.isEmpty(inputName.text.toString())){
            inputName.error="Enter Your Name"
            return
        }else if(isDeliveryOn&&TextUtils.isEmpty(inputAddress.text.toString())){
            inputAddress.error="Enter Your Address"
            return
        }else if(isDeliveryOn&&TextUtils.isEmpty(inputCity.text.toString())){
            inputCity.error="Enter Your City Name"
            return
        }else if(isDeliveryOn&&TextUtils.isEmpty(inputZip.text.toString())){
            inputZip.error="Enter Your Zip code"
            return
        }else if(TextUtils.isEmpty(inputCardNumber.text.toString())){
            inputCardNumber.error="Enter Your credit card number"
            return
        }else if(TextUtils.isEmpty(inputCardExpiry.text.toString())){
            inputCardExpiry.error="Enter Your credit card expiry"
            return
        }else if(TextUtils.isEmpty(inputCardPin.text.toString())){
            inputCardPin.error="Enter Your credit card expiry"
            return
        }
        val intent = Intent(this@PlaceYourOrderActivity,SuccessOrderActivity::class.java)
        intent.putExtra("RestaurantModel",restaurantModel)
        startActivityForResult(intent,1000)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(resultCode==1000){
            setResult(RESULT_OK)
            finish()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home -> finish()
            else ->{

            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        setResult(RESULT_CANCELED)
        finish()
    }
}