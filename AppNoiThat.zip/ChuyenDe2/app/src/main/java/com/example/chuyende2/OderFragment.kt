package com.example.chuyende2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.example.chuyende2.databinding.FragmentOderBinding
import com.example.chuyende2.model.Order
import com.example.chuyende2.adapter.OderAdapter
import com.example.chuyende2.viewmodels.ProductViewModel
import com.google.firebase.database.FirebaseDatabase
import java.text.NumberFormat

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

class OderFragment : Fragment() {

    private var _binding : FragmentOderBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProductViewModel by activityViewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentOderBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView = binding.productRecyclerView
        recyclerView.adapter = OderAdapter(viewModel.orderProduct.value!!)
        binding.apply {
            val currencyFormat: NumberFormat = NumberFormat.getCurrencyInstance()
            total.text = currencyFormat.format(viewModel.total.value)
            payButton.setOnClickListener{
                oderProduct()
            }
        }
    }

    private fun oderProduct() {
        val database = FirebaseDatabase.getInstance()
        val ordersRef = database.getReference("Orders")
        val orderId = ordersRef.push().key // Tạo một key duy nhất cho đơn hàng
        binding.apply {
        val order = Order(orderId, viewModel.id, customerNameEditText.text.toString(),customerPhoneNumber.text.toString(),city.text.toString(),
            street.text.toString(), houseNumber.text.toString(),
            viewModel.orderProduct.value)
        ordersRef.child(orderId!!).setValue(order).addOnCompleteListener{
            Toast.makeText(context,"Oder is complete, wait to get the phone",Toast.LENGTH_SHORT)
        }
        }
    }

}