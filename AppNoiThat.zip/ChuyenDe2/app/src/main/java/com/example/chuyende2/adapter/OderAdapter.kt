package com.example.chuyende2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.chuyende2.R
import com.example.chuyende2.model.Products

class OderAdapter(private val productList: List<Products>) : RecyclerView.Adapter<OderAdapter.ViewHolder>() {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val productNameTextView: TextView = itemView.findViewById(R.id.productNameTextView)
            val productPriceTextView: TextView = itemView.findViewById(R.id.productPriceTextView)
            val productQuantityTextView: TextView =
                itemView.findViewById(R.id.productQuantityTextView)
        val productImage: ImageView = itemView.findViewById(R.id.productImageView)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_order, parent, false)
            return ViewHolder(view)
        }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val product = productList[position]
            holder.productNameTextView.text = product.name
            holder.productPriceTextView.text = product.price
            holder.productQuantityTextView.text = product.quantity

        productList.get(position)?.thumbnail?.let {
            val imgUri = it.toUri().buildUpon().scheme("https").build()
            holder.productImage.load(imgUri) {
                placeholder(R.drawable.loading_animation)
                error(R.drawable.ic_broken_image)
            }
        }
        }


    }