package com.example.recipe.adapter

import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.recipe.R
import com.example.recipe.models.Hours
import com.example.recipe.models.RestaurantModel
import java.text.SimpleDateFormat
import java.util.*

class RestaurantListAdapter(val restauranList: List<RestaurantModel?>?, val clickListener: RestaurantListClicker): RecyclerView.Adapter<RestaurantListAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): RestaurantListAdapter.MyViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.recycler_restautr_list_row, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: RestaurantListAdapter.MyViewHolder, position: Int) {
        holder.bind(restauranList?.get(position))
        holder.itemView.setOnClickListener {
            clickListener.onItemClick(restauranList?.get(position)!!)
        }

    }

    override fun getItemCount(): Int {

        return restauranList?.size!!
    }
    inner class MyViewHolder(view: View):RecyclerView.ViewHolder(view){
        val thumbImage: ImageView = view.findViewById(R.id.thumbImage)
        val tvRestaurantName: TextView= view.findViewById(R.id.tvRestaurantName)
        val tvRestaurantAddress: TextView= view.findViewById(R.id.tvRestaurantNameAddress)
        val tvRestaurantHours: TextView= view.findViewById(R.id.tvRestaurantNameHours)

        fun bind(restaurentModel: RestaurantModel?){
            tvRestaurantName.text=restaurentModel?.name
            tvRestaurantAddress.text="Address: "+restaurentModel?.address
            tvRestaurantHours.text="Today's Hours: "+getTodayHours(restaurentModel?.hours!!)
            Glide.with(thumbImage).
                    load(restaurentModel?.image)
                .into(thumbImage)
        }
    }
    private fun getTodayHours(hours: Hours): String?{
        val calendar: Calendar= Calendar.getInstance()
        val date:Date = calendar.time
        val day: String = SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.time)
        return when(day) {
            "Sunday" -> hours.Sunday
            "Monday" -> hours.Monday
            "Tuesday" -> hours.Tuesday
            "Wednesday"-> hours.Wednesday
            "Thursday" -> hours.Thursday
            "Friday" -> hours.Friday
            "Saturday" -> hours.Saturday
            else -> hours.Sunday
        }
    }
    interface RestaurantListClicker{
        fun onItemClick(restaurantModel: RestaurantModel)

    }
}