package com.example.chuyende2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.chuyende2.R
import com.example.chuyende2.model.Products
import com.example.chuyende2.viewmodels.ProductViewModel
import java.text.NumberFormat

class ProductAdapter(private val viewModel: ProductViewModel,val int: Int,val lambda:(String) -> Unit) :RecyclerView.Adapter<ProductAdapter.ProducViewHoder>(){

    class ProducViewHoder(val view: View) : RecyclerView.ViewHolder(view) {
        val image = view.findViewById<ImageView>(R.id.image_table)
        val tx1 = view.findViewById<TextView>(R.id.textTable1)
        val tx2 = view.findViewById<TextView>(R.id.textTable2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProducViewHoder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.product_cart, parent, false)
        return ProducViewHoder(layout)
    }

    override fun getItemCount(): Int {
        if(int ==0)
       return viewModel.products.value?.size ?: 0
        else
            return viewModel.lookProduct.value?.size ?: 0
    }

    override fun onBindViewHolder(holder: ProducViewHoder, position: Int) {
        var product: Products
        if(int == 0) { product = viewModel.products.value?.get(position)!!}
        else { product = viewModel.lookProduct.value?.get(position)!!}
        holder.view.setOnClickListener {
            lambda(product.id.toString())
        }
        holder.tx1.text = product.name ?: ""
        val currencyFormat: NumberFormat = NumberFormat.getCurrencyInstance()
        holder.tx2.text =  currencyFormat.format(product.price?.toDouble() ?: "")
        product.thumbnail?.let {
            val imgUri = it.toUri().buildUpon().scheme("https").build()
            holder.image.load(imgUri) {
                placeholder(R.drawable.loading_animation)
                error(R.drawable.ic_broken_image)
            }
        }
    }
}

