package com.example.chuyende2

import CartFragment
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.SearchView
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        bottomNavigationView = findViewById(R.id.bottom_navigation)
        // Thiết lập sự kiện lắng nghe khi chuyển đổi giữa các Fragment

        supportFragmentManager.addOnBackStackChangedListener {
            val fragment = supportFragmentManager.findFragmentById(R.id.bottom_navigation)
            if (fragment is OderFragment || fragment is CartFragment || fragment is AccountFragment||
                    fragment is ProductGridFragment || fragment is ProductDetailFragment || fragment is PoliceFragment) {
                showBottomNavigation()
            } else {
                hideBottomNavigation()
            }
        }
            bottomNavigationView.setOnNavigationItemReselectedListener { item ->
                when (item.itemId) {
                    R.id.page_1 -> {
                        // Respond to navigation item 1 reselection
                        navController.navigate(R.id.productGridFragment)
                    }
                    R.id.page_2 -> {
                        // Respond to navigation item 2 reselection
                        navController.navigate(R.id.cartFragment)
                    }
                    R.id.page_3 -> {
                        navController.navigate(R.id.accountFragment)
                    }
                }
            }
    }
    fun showBottomNavigation() {
        bottomNavigationView.visibility = View.VISIBLE
    }

    fun hideBottomNavigation() {
        bottomNavigationView.visibility = View.GONE
    }
}