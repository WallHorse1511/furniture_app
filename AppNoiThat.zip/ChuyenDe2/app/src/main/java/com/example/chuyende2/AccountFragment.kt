package com.example.chuyende2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.chuyende2.databinding.FragmentAccountBinding
import com.example.chuyende2.databinding.FragmentCartBinding
import com.example.chuyende2.viewmodels.ProductViewModel

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class AccountFragment : Fragment() {
    private val viewModel: ProductViewModel by activityViewModels()
    private var _binding : FragmentAccountBinding? = null
    private val binding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val activity = requireActivity()
        activity.title = "Account"
        // Inflate the layout for this fragment
        _binding = FragmentAccountBinding.inflate(inflater, container, false)
        (activity as MainActivity).showBottomNavigation()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            userName.text = viewModel.name
            logOut.setOnClickListener {
                findNavController().navigate(R.id.action_accountFragment_to_loginFragment)
            }
            police.setOnClickListener {
                findNavController().navigate(R.id.action_accountFragment_to_policeFragment)
            }
            waitCheck.setOnClickListener {
                viewModel.status = 0
                findNavController().navigate(R.id.action_accountFragment_to_orderDeliveryFragment)
            }
            waitOrder.setOnClickListener {
                viewModel.status = 1
                findNavController().navigate(R.id.action_accountFragment_to_orderDeliveryFragment)
            }
        }
    }

}