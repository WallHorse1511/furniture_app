package com.example.chuyende2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.chuyende2.R
import com.example.chuyende2.model.Order
import com.example.chuyende2.model.Products

class OderDeliveryAdapter(private val productList: List<Order>) : RecyclerView.Adapter<OderDeliveryAdapter.ViewHolder>() {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_recycleview, parent, false)
        return OderDeliveryAdapter.ViewHolder(view)
    }
    override fun getItemCount(): Int {
        return productList.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val childRecyclerView = holder.itemView.findViewById<RecyclerView>(R.id.childRecyclerView)
        childRecyclerView.layoutManager = LinearLayoutManager(holder.itemView.context, LinearLayoutManager.HORIZONTAL, false)
        childRecyclerView.adapter = ChildAdapter(productList[position].productList!!)
    }
}


class ChildAdapter(val order: List<Products>) : RecyclerView.Adapter<ChildAdapter.ChildViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_order, parent, false)
        return ChildViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ChildViewHolder, position: Int) {
        val product = order[position]
        holder.productNameTextView.text = product.name
        holder.productPriceTextView.text = product.price
        holder.productQuantityTextView.text = product.quantity
    }

    override fun getItemCount(): Int {
        return order.size
    }

    class ChildViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val productNameTextView: TextView = itemView.findViewById(R.id.productNameTextView)
        val productPriceTextView: TextView = itemView.findViewById(R.id.productPriceTextView)
        val productQuantityTextView: TextView =
            itemView.findViewById(R.id.productQuantityTextView)
        val productImage: ImageView = itemView.findViewById(R.id.productImageView)
    }
}