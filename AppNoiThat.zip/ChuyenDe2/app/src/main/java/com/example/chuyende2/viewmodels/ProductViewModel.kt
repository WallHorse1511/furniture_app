package com.example.chuyende2.viewmodels

import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.chuyende2.model.Category
import com.example.chuyende2.model.Products
import com.example.chuyende2.model.User
import com.google.firebase.database.*

class ProductViewModel(): ViewModel(){
    private var _products = MutableLiveData<List<Products>>()
    val products: LiveData<List<Products>> = _products
    private lateinit var dbRef: DatabaseReference
    // The internal MutableLiveData that stores the status of the most recent request
    var id: String? = null
    var name: String?= null
    var _categoris = MutableLiveData<MutableList<Products>>()
    val categoris: LiveData<MutableList<Products>> = _categoris

    private var _total = MutableLiveData<Double>(0.0)
    val total: LiveData<Double> = _total
    var status = 0
    private var _orderProduct = MutableLiveData<MutableList<Products>>()
    val orderProduct: LiveData<MutableList<Products>> = _orderProduct

    private var _lookProduct = MutableLiveData<List<Products>>()
    val lookProduct: LiveData<List<Products>> = _lookProduct
    init {
        getProducts()
//        getCategoris()
    }
    fun lookProducts(st: String){
        _lookProduct.value = products.value?.filter { it.name!!.contains(st) }
    }
    fun plusTotal(number: Double){
        _total.value= _total.value?.plus(number)
    }
    private fun getCategoris() {

    }
    fun subCardProduct(product: Products){
        product.quantity = "1"
        var list =_categoris.value?.toMutableList() ?: mutableListOf<Products>()
        list.remove(product)
        _categoris.value = list
    }
    fun addCardProduct(product: Products){
        product.quantity = "1"
        var list =_categoris.value?.toMutableList() ?: mutableListOf<Products>()
        list.add(product)
        _categoris.value = list
    }
    fun addquantityCard(int: Int){

    }
    fun addOrderProduct(product: Products){
        product.quantity = "1"
        var list =_orderProduct.value?.toMutableList() ?: mutableListOf<Products>()
        list.add(product)
        _orderProduct.value = list
    }
    fun subOrderProduct(product: Products){
        product.quantity = "1"
        var list =_orderProduct.value?.toMutableList() ?: mutableListOf<Products>()
        list.remove(product)
        _orderProduct.value = list
    }
    private fun getProducts() {
//        _products.value = listOf(
//            Products(
//                "1",
//                "Bàn ủi Panasonic NI-317TVRA",
//                "ban ui",
//                "vật liệu 1",
//                "Bàn ghế A",
//                "360.000",
//                "10",
//                "S,M,L",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/600/336/detailed/15/10018389-ban-ui-panasonic-ni-317tvra.jpg"
//            ),
//            Products(
//                "2",
//                "Mô tả sản phẩm 2",
//                "type2",
//                "vật liệu 2",
//                "Bàn ghế B",
//                "200.0",
//                "20",
//                "M,L,XL",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/180/180/detailed/666/10046688-ban-ui-hoi-nuoc-philips-gc487-1.jpg"
//            ),
//            Products(
//                "3",
//                "Mô tả sản phẩm 3",
//                "type1",
//                "vật liệu 3",
//                "Bàn ghế C",
//                "300.0",
//                "30",
//                "L,XL,XXL",
//                "https://example.com/ban-ghe-c.jpg"
//            ),
//            Products(
//                "4",
//                "Mô tả sản phẩm 2",
//                "type2",
//                "vật liệu 2",
//                "Bàn ghế B",
//                "200.0",
//                "20",
//                "M,L,XL",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/180/180/detailed/666/10046688-ban-ui-hoi-nuoc-philips-gc487-1.jpg"
//            ),
//            Products(
//                "5",
//                "Mô tả sản phẩm 3",
//                "type1",
//                "vật liệu 3",
//                "Bàn ghế C",
//                "300.0",
//                "30",
//                "L,XL,XXL",
//                "https://example.com/ban-ghe-c.jpg"
//            ),
//            Products(
//                "6",
//                "Bàn ủi Panasonic NI-317TVRA",
//                "ban ui",
//                "vật liệu 1",
//                "Bàn ghế A",
//                "360.000",
//                "10",
//                "S,M,L",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/600/336/detailed/15/10018389-ban-ui-panasonic-ni-317tvra.jpg"
//            ),
//            Products(
//                "7",
//                "Bàn ủi Panasonic NI-317TVRA",
//                "ban ui",
//                "vật liệu 1",
//                "Bàn ghế A",
//                "360.000",
//                "10",
//                "S,M,L",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/600/336/detailed/15/10018389-ban-ui-panasonic-ni-317tvra.jpg"
//            ),
//            Products(
//                "8",
//                "Bàn ủi Panasonic NI-317TVRA",
//                "ban ui",
//                "vật liệu 1",
//                "Bàn ghế A",
//                "360.000",
//                "10",
//                "S,M,L",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/600/336/detailed/15/10018389-ban-ui-panasonic-ni-317tvra.jpg"
//            ),
//            Products(
//                "9",
//                "Bàn ủi Panasonic NI-317TVRA",
//                "ban ui",
//                "vật liệu 1",
//                "Bàn ghế A",
//                "360.000",
//                "10",
//                "S,M,L",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/600/336/detailed/15/10018389-ban-ui-panasonic-ni-317tvra.jpg"
//            ),
//            Products(
//                "10",
//                "Bàn ủi Panasonic NI-317TVRA",
//                "ban ui",
//                "vật liệu 1",
//                "Bàn ghế A",
//                "360.000",
//                "10",
//                "S,M,L",
//                "https://cdn.nguyenkimmall.com/images/thumbnails/600/336/detailed/15/10018389-ban-ui-panasonic-ni-317tvra.jpg"
//            )
//        )
//
//        dbRef = FirebaseDatabase.getInstance().getReference("Products")
//
//        for (pro in products.value!!) {
//            val userID = dbRef.push().key!!
//            pro.id= userID
//                dbRef.child(pro.id!!).setValue(pro).addOnCompleteListener {
//
//                }
//                    .addOnFailureListener {
//                    }
//        }
//    }
        dbRef = FirebaseDatabase.getInstance().getReference("Products")
        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val productList: MutableList<Products> = mutableListOf()

                for (productSnapshot in dataSnapshot.children) {
                    val product: Products? = productSnapshot.getValue(Products::class.java)
                    product?.let {
                        productList.add(it)
                    }
                }

                _products.value = productList
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
//        dbRef = FirebaseDatabase.getInstance().getReference("Products")
//        dbRef.addValueEventListener(object : ValueEventListener {
//            override fun onDataChange(snapshot: DataSnapshot) {
//                if(snapshot.exists()){
//                    var list: ArrayList<Products> = ArrayList<Products>()
//                    for (userSnap in snapshot.children){
//                        val userData = userSnap.getValue(Products::class.java)
//                         list.add(userData!!)
//                    }
//                    _products.value = list.toList()
//                }
//            }

//            override fun onCancelled(error: DatabaseError) {
//                TODO("Not yet implemented")
//            }
//        })
    }
}