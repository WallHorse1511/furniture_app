package com.example.chuyende2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.chuyende2.adapter.OderAdapter
import com.example.chuyende2.adapter.OderDeliveryAdapter
import com.example.chuyende2.databinding.FragmentCartBinding
import com.example.chuyende2.databinding.FragmentOrderDeliveryBinding
import com.example.chuyende2.model.Order
import com.example.chuyende2.model.Products
import com.example.chuyende2.viewmodels.ProductViewModel
import com.google.firebase.database.*
import java.text.NumberFormat

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

class OrderDeliveryFragment : Fragment() {
    private val viewModel: ProductViewModel by activityViewModels()
    private var _binding : FragmentOrderDeliveryBinding? = null
    private lateinit var dbRef : DatabaseReference
    private val binding get() = _binding!!
    private lateinit var listProduct: MutableList<Order>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentOrderDeliveryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.ctnPc.setOnClickListener {
            findNavController().navigate(R.id.action_orderDeliveryFragment_to_productGridFragment)
        }
        dbRef = FirebaseDatabase.getInstance().getReference("Orders")
        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val productList: MutableList<Order> = mutableListOf()

                for (productSnapshot in dataSnapshot.children) {
                    val product: Order? = productSnapshot.getValue(Order::class.java)
                    product?.let {
                        productList.add(it)
                    }
                }
                listProduct = productList
                if (listProduct.isNotEmpty()){
                    val recyclerView = binding.recyclerView
                    recyclerView.adapter = OderDeliveryAdapter(listProduct)
                    binding.apply {
                        quantity.text = resources.getString(R.string.quantity_items,listProduct.size)
                        val currencyFormat: NumberFormat = NumberFormat.getCurrencyInstance()
                        var sum= 0.0
                        listProduct.forEach { it.productList?.forEach { sum = sum+ it.price!!.toDouble()*it.quantity!!.toInt()  } }
                        total.text = resources.getString(R.string.total_s, currencyFormat.format(sum))
                    }
                    when(listProduct[0].status){
                        0 -> if(viewModel.status==0)binding.bt.setText("Wait to check") else {
                        binding.gr1.visibility = View.GONE
                        binding.gr2.visibility = View.VISIBLE
                    }
                        1 -> if(viewModel.status==1) binding.bt.setText("On Delivering")  else{
                        binding.gr1.visibility = View.GONE
                        binding.gr2.visibility = View.VISIBLE
                    }
                        else ->{
                            binding.gr1.visibility = View.GONE
                            binding.gr2.visibility = View.VISIBLE
                        }
                    }
                }
                else{
                    binding.gr1.visibility = View.GONE
                    binding.gr2.visibility = View.VISIBLE
                }
            }

            override fun onCancelled(error: DatabaseError) {
               binding.gr1.visibility = View.GONE
                binding.gr2.visibility = View.VISIBLE
            }
        })

    }

}