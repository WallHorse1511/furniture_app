package com.example.chuyende2

import android.os.Bundle
import android.view.*
import android.widget.SearchView
import android.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.chuyende2.adapter.ProductAdapter
import com.example.chuyende2.databinding.FragmentProductGridBinding
import com.example.chuyende2.viewmodels.ProductViewModel
import com.google.android.material.appbar.MaterialToolbar


class ProductGridFragment : Fragment() {
    private var _binding :FragmentProductGridBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProductViewModel by activityViewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val activity = requireActivity()
        activity.title = "Product"
        _binding = FragmentProductGridBinding.inflate(inflater, container, false)
        val view = binding.root
        setHasOptionsMenu(true)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView = binding.recyclerView
        (activity as MainActivity).showBottomNavigation()
        recyclerView.adapter = ProductAdapter(viewModel,0){
            val bundle = Bundle()
            bundle.putSerializable("id", it)
            findNavController().navigate(R.id.action_productGridFragment_to_productDetailFragment, bundle)
        }
        binding.notice.visibility = View.GONE
//        if(viewModel.products.value?.isEmpty() != false){
//   //         findNavController().navigate(R.id.productGridFragment)
//            binding.notice.text = "Error network"
//            binding.notice.visibility = View.VISIBLE
//        }else{
//            binding.notice.visibility = View.GONE
//        }

    }


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.search_menu, menu)

        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem?.actionView as SearchView
        // Xử lý sự kiện tìm kiếm ở đây
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                // Xử lý khi nhấn nút tìm kiếm
                viewModel.lookProducts(query)
                val recyclerView = binding.recyclerView
                recyclerView.adapter = ProductAdapter(viewModel,1){
                    val bundle = Bundle()
                    bundle.putSerializable("id", it)
                    findNavController().navigate(R.id.action_productGridFragment_to_productDetailFragment, bundle)
                }
                if(viewModel.lookProduct.value?.isEmpty() != false){
                    binding.notice.visibility = View.VISIBLE
                }else{
                    binding.notice.visibility = View.GONE
                }
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                // Xử lý khi thay đổi nội dung tìm kiếm
                return false
            }
        })
        super.onCreateOptionsMenu(menu, inflater)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_search -> {
                // Xử lý khi người dùng nhấn vào mục tìm kiếm
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}